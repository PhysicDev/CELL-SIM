:: [L I C E N C J A] :: 

:: autorem tego fonta jest ATRAX Rafa� Brzezi�ski
font zawiera du�e i ma�e litery oraz niekt�re znaki interpunkcyjne.

:: mo�esz : 
--->tworzy� dowoln� ilo�� kopii fonta 
--->instalowa� fonta na dowolnej liczbie komputer�w 
---> wykorzystywa� go na stronach www, w publikacjach papierowych i elektronicznych pod warunkiem, �e nie maj� one charakteru komercyjnego [tzn. przygotowujesz je na sw�j w�asny u�ytek a nie w celu zarobienia pieni�dzy] 
---> udost�pnia� fonta na stronie www ale pod warunkiem, �e zachowasz plik z czcionk� bez zmian i w widocznym      miejscu poinformujesz kto jest autorem fonta 

:: bez zgody autora nie mo�esz modyfikowa� pliku z fontem, a szczeg�lnie zmienia� nazwy fonta, usuwa� informacji o     autorze, usuwa� pliku z licencj� 
   u�ywa� fonta do jakichkolwiek dzia�a� komercyjnych 
   sprzedawa� fonta albo udost�pnia� go na p�atnych, lub cz�ciowo p�atnych stronach www 

:: wszelkie uwagi prosz� kierowa� na adres : antrax27@wp.pl
Rafa� Brzezi�ski 

:: najnowsze wersje  moich font�w znajdziesz zawsze na stronie : http://antraxja-fonts.iweb.pl 

Je�li chesz u�ywa� tego fonta w celach komercyjnych prosz� o kontakt. Pe�na wersja fonta pozbawiona jest loga pod znaczkem @ 

ATRAX
Rafa� Brzezi�ski 
antrax27@wp.pl
http://antraxja-fonts.iweb.pl
----------------------------------------------------------------------------------------------------
The font RETURN TO CASTLE  that was designed by me,
contains large letters, digits
and some punctuations.

It's freeware.
You can use it in your private projects,
if you want to put it to the commercial
projects please let me know.

font can be redistributed in condition
that it will be free of charge 
and with this readme file attached.

Hope you like RETURN TO CASTLEand it will be
useful in your work :)


ATRAX
Rafa� Brzezi�ski 
antrax27@wp.pl
http://antraxja-fonts.iweb.pl