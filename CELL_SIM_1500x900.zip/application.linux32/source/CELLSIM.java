import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Vector; 
import java.util.Collections; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CELLSIM extends PApplet {



Vector<Cell> cells = new Vector<Cell>();
Vector<Food> foods = new Vector<Food>();

int pop = 80;
int foodN = 200;
int food_target = 200;
int loop = 0;
int foodPerMin = 220;
float foodPeriod = 60/foodPerMin;

boolean run = false;
boolean reset = true;

Button lanch_sim;
Button pause_sim;
Button stop_sim;


Radio food_mode;
Radio food_show;
Slider food_start;
Slider food_growth;


Slider cell_start;
Slider start_speed;
Slider start_size;
Slider start_cylcle;
Slider start_ratio;
Slider food_ratio;

PFont return_to_castle;

Graphic foodCurve;
Graphic cellCurve;

float loopTime;
float chrono = 0;

public void setup(){
    foodCurve = new Graphic(" food population ",1250,200,500,375,color(80,90,80),color(0),0);
    foodCurve.set_font(createFont(dataPath("font/return_to_castle/return.ttf"),40),color(230),color(120));
    foodCurve.set_lines(true,true,0.1f,0.1f,color(240),2,color(240,0,0),3,1,1,"m","s");
    
    return_to_castle = createFont(dataPath("font/return_to_castle/return.ttf"),30);
    
    cellCurve = new Graphic(" cell population ",1250,600,500,375,color(80,90,80),color(0),0);
    cellCurve.set_font(createFont(dataPath("font/return_to_castle/return.ttf"),40),color(230),color(120));
    cellCurve.set_lines(true,true,0.1f,0.1f,color(240),2,color(240,0,0),3,1,1,"m","s");
  
  food_mode = new Radio("mode " , 22,140,20,color(90,90,90),color(80,80,80),1.5f,"ROND");
  food_mode.set_cursor("CROIX",15,color(140,40,40));
  
  food_show = new Radio("show " , 222,775,20,color(90,90,90),color(80,80,80),1.5f,"ROND");
  food_show.set_cursor("CROIX",15,color(140,40,40));
  
  food_start = new Slider("nourriture de depart",10,185,180,40,140, color(230),2);
  food_start.set_text("nourriture de depart",color(230),16.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  food_start.set_cursor(1,5,20,color(100),color(200),3);
  food_start.set_grad(10,500,100,20,200);
  food_start.round_value = true;
  
  food_growth = new Slider("vitesse de croissance",10,255,180,40,140, color(230),2);
  food_growth.set_text("vitesse de croissance",color(230),16.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  food_growth.set_cursor(1,5,20,color(100),color(200),3);
  food_growth.set_grad(0,500,100,20,220);
  food_growth.round_value = true;
  
  
  
  
   cell_start = new Slider("nouriture de depart",10,185,180,40,140, color(230),2);
  cell_start.set_text("cellules de depart",color(230),16.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  cell_start.set_cursor(1,5,20,color(100),color(200),3);
  cell_start.set_grad(10,500,100,20,100);
  cell_start.round_value = true;
  
  start_speed = new Slider("vitesse de croissance",10,255,180,40,140, color(230),2);
  start_speed.set_text("vitesse de deplacement",color(230),14.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  start_speed.set_cursor(1,5,20,color(100),color(200),3);
  start_speed.set_grad(0,160,20,5,30);
  start_speed.round_value = true;
  
   start_size = new Slider("nouriture de depart",10,185,180,40,140, color(230),2);
  start_size.set_text("taille de depart",color(230),16.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  start_size.set_cursor(1,5,20,color(100),color(200),3);
  start_size.set_grad(10,100,20,5,30);
  start_size.round_value = true;
  
  start_cylcle = new Slider("vitesse de depart",10,255,180,40,140, color(230),2);
  start_cylcle.set_text("duree d'un cycle",color(230),16.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  start_cylcle.set_cursor(1,5,20,color(100),color(200),3);
  start_cylcle.set_grad(0,30,10,2,5);
  start_cylcle.round_value = true;
  
  start_ratio = new Slider("nouriture de depart",10,185,180,40,140, color(230),2);
  start_ratio.set_text("ressources de naissance",color(230),13.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  start_ratio.set_cursor(1,5,20,color(100),color(200),3);
  start_ratio.set_grad(0,1,0.1f,0.025f,0.3f);
  //start_ratio.round_value = true;
  
  food_ratio = new Slider("demande en nourriture",10,255,180,40,140, color(230),2);
  food_ratio.set_text("besoin en nourriture",color(230),16.0f,createFont(dataPath("font/Spac3/Spac3.ttf"),30));
  food_ratio.set_cursor(1,5,20,color(100),color(200),3);
  food_ratio.set_grad(0,0.005f,0.001f,0.00025f,0.001f);
  //food_ratio.round_value = true;
  
  
  
  lanch_sim = new Button("",12,15,50,50);
  lanch_sim.set_image(loadImage(dataPath("img/icon_play.png")));
  lanch_sim.click_effect = true;
  pause_sim = new Button("",76,15,50,50);
  pause_sim.set_image(loadImage(dataPath("img/icon_pause.png")));
  pause_sim.click_effect = true;
  stop_sim = new Button("",141,15,50,50);
  stop_sim.set_image(loadImage(dataPath("img/icon_stop.png")));
  stop_sim.click_effect = true;
  
  
  
    
   
  
   
   textAlign(CENTER,CENTER);
   noStroke();
   ellipseMode(CENTER);
}

public void draw(){
  
   
   noStroke();
   background(60); 
   fill(100,100,100);
   rect(200,0,800,800);
   if(run){
     float time = 1/frameRate;
     loopTime += time;
     chrono += time;
     if(!food_mode.activate){
       if(loopTime > foodPeriod){
         
         foods.add(new Food());
         foodN += 1;
         loopTime -= foodPeriod;
         
       }
     }else{
      
       while(foodN < food_target){
        
         foodN += 1;
         foods.add(new Food());
         
       }
       
     }
     
     
     for(int i = 0 ; i < foodN ; i++){
        foods.elementAt(i).update(); 
     }
     textSize(11);
     for(loop = 0 ; loop < pop ; loop++){
        cells.elementAt(loop).update(time); 
     }
     
     
     
     fill(250,250,250);
     textAlign(LEFT,TOP);
     textSize(12);
     text("foods : "+ foodN  + " || cells : " + pop,200,0);
     textAlign(CENTER);
     
     foodCurve.add(foodN,chrono);
     cellCurve.add(pop,chrono);
   }
   foodCurve.show();
   if(foodCurve.lenght/foodCurve.ratio > 5000){
       //foodCurve.simplify(1);
       foodCurve.ratio += 1;
   }
   
   cellCurve.show();
   if(cellCurve.lenght/cellCurve.ratio > 5000){
       //cellCurve.simplify(1);
       cellCurve.ratio += 1;
   }
   
   
   lanch_sim.update();
   pause_sim.update();
   stop_sim.update();
   
   if(lanch_sim.activate){
      run= true; 
      if(reset){
        chrono = 0;
       reset = false;
       foodCurve.reset();
       cellCurve.reset();
       cells.removeAllElements();
       foods.removeAllElements();
       pop = (int)cell_start.value;
       foodN = (int)food_start.value;
       food_target = foodN;
        for(int i = 0; i < pop ; i++){
          
            cells.add(new Cell()); 
           
         }
         for(int i = 0; i < foodN ; i++){
          
            foods.add(new Food()); 
           
         }
       
      }
   }
   
   if(pause_sim.activate){
     if(!reset){
       run = !run;
     }
   }
   
   if(stop_sim.activate){
    
     run = false;
     reset = true;
     
   }
   food_show.update();
   
   float decalage = 0;
   food_mode.update();
   food_start.update();
   
    
   
   textFont(return_to_castle);
   
  stroke(150,150,150);
  fill(150,150,150);
  textAlign(CENTER,TOP);
  textSize(20);
  strokeWeight(2);
  
  line(6,85,194,85);
  text("NOURITURE",100,100);
  text(round(food_start.value),100,205);
  if(!food_mode.activate){
    text(round(food_growth.value),100,275);
    text("mode : croissant",130,130);
    food_growth.update();
  }else{
    text("mode : constant",130,130);
    decalage = 70;
    
  }
  
  
    cell_start.y = 370 -decalage ;
    start_speed.y = 440 -decalage ;
    start_size.y = 510 -decalage ;
    start_cylcle.y = 580 -decalage ;
    start_ratio.y = 650 -decalage ;
    food_ratio.y = 720 -decalage ;
    
    cell_start.update();
    start_speed.update();
    start_size.update();
    start_cylcle.update();
    start_ratio.update();
    food_ratio.update();
    
    textFont(return_to_castle);
    stroke(150,150,150);
    fill(150,150,150);
    textAlign(CENTER,TOP);
    textSize(20);
    strokeWeight(2);
  
  
  line(6,295-decalage,194,295-decalage);
  text("CELLULES",100,310-decalage);
    text(round(cell_start.value),100,390-decalage );
    text(round(start_speed.value),100,450-decalage );
    text(round(start_size.value),100,520-decalage );
    text(round(start_cylcle.value),100,590-decalage );
    text(((float)round(start_ratio.value*100)/100),100,660-decalage );
    text(((float)round(food_ratio.value*1000000)/10000),100,730-decalage );
  
  
  
  

}

class Cell{
  
  
  //paramètres
  float x,y,s,tx = random(800)+200,ty = random(800);
  float cycle = 5 + random(1);
  float Ccycle = cycle -0.5f + random(1);
  float foodGive = 0.5f;
  float speed = random(5)+20;
  
  //temps local
  float localTime;
  
  //food
  float calories = 100;
  
  
  Cell()
  {
    
      x = random(800)+200;
      y = random(800);
      s = random(5)-2.5f+start_size.value;
      speed = random(5)-2.5f+ start_speed.value;
      cycle = start_cylcle.value -0.5f + random(1);
      Ccycle = cycle -0.5f + random(1);
      foodGive = start_ratio.value;
  }
  
  Cell(Cell _cell, float food){
    calories = food;
    
    x = _cell.x + random(50)-25;
    y = _cell.y + random(50)-25;
    s = _cell.s + random(2)-1;
    if(s < 10){
       s = 10;
    }
    speed = _cell.speed + random(2)-1;
    cycle = _cell.cycle + random(1)-0.5f;
    foodGive = _cell.foodGive * (random(0.1f)+0.95f);
   
   
    
    
  }
  
  
  public void update(float time){
   
    
     //===========================================  Maths
     
     //birth
     localTime += time;
     if(localTime > Ccycle){
        localTime -= Ccycle;
        Ccycle = cycle - 0.5f + random(1);
        if(calories > 5*s){
          pop += 1;
          cells.add(new Cell(this,calories*foodGive));
          calories -= calories*foodGive*0.4f;
        }
     }
     
     
     //move
     float D = dist(tx,ty,x,y);
     float ratio = (speed * time)/D;
     x += (tx - x) * ratio ;
     y += (ty - y) * ratio ;
     
     if(x < 200){
        x = 200;
     }
     if(y < 0){
        y = 0; 
     }
     if(x > 1300){
        x = 1300; 
     }
     if(y > 800){
       y = 800;
     }  
     
     
     
     //starve
     calories -= speed * time * food_ratio.value * pow(s/2,1.8f)*PI;
     if(calories < 0){
       loop -= 1;
       pop -= 1;
       cells.removeElementAt(loop+1);
     }
     
     
     //food detector
     float nearFood = 999;
     float potentialTX = 0;
     float potentialTY = 0;
     
     for(int j = 0; j < foodN; j++){
       Food f = foods.elementAt(j);
       if(dist(x,y,f.x,f.y) < (s)/2){
         
         calories += 10;
         foods.removeElementAt(j);
         foodN -= 1;
         j -= 1;
         
       }
       
       if(dist(x,y,f.x,f.y) < nearFood){
         nearFood = dist(x,y,f.x,f.y);
         potentialTX = f.x;
         potentialTY = f.y;
       }
     }
     
     //cells collisions
     for(int j = 0; j < pop; j++){
       if(j != loop){
         Cell c = cells.elementAt(j);
         if(c.s > s * 0.8f && c.s < s * 1.2f){
           if(dist(x,y,c.x,c.y) < (s+c.s)/2){
             
             float R = ((s+c.s)/2) / dist(x,y,c.x,c.y) -1;
            
             x += ((x-c.x)*R);
             y += ((y-c.y)*R);
             
           }
         }else{
           
           if(c.s <  s * 0.8f){
             
             if(dist(x,y,c.x,c.y) < (s-(c.s*0.75f))/2){
               
               calories += c.s*5+c.calories/10;
               cells.removeElementAt(j);
               pop -= 1;
               j -= 1;
               if(j < loop){
                  loop -= 1; 
               }
               
             }
             if(dist(x,y,c.x,c.y) < nearFood){
               nearFood = dist(x,y,c.x,c.y);
               potentialTX = c.x;
               potentialTY = c.y;
             }
             
           }
           
         }
       }
     }
     
     
     
     //si pas de nouriture trouvée
     if(nearFood > 800){
       if(round(x) == round(tx) && round(y) == round(ty)){
           tx = random(800)+200;
           ty = random(800);
       }
     }else{
       tx = potentialTX;
       ty = potentialTY;
     }
     
     
     
      
     //draw
     fill(calories,(calories-250),(calories-250));
     ellipse(x,y,s,s);
     fill(240,240,240);
     if(food_show.activate){
       text(round(calories),x,y);
     }
     
    
  }
  
}

class Food{
  
  float x,y;
  
  Food()
  {
      
      x = random(800)+200;
      y = random(800);
      
  }  
  
  public void update(){
   
    
    //draw
    fill(0,240,0);
    ellipse(x,y,5,5);
    
  }
  
}
  
public class Button{
  
  // nom du bouton
  String name;
  
  // position / taille / taille du texte / poids du stroke / taille d'ombre /position de l'ombre
  float x,y,w,h,t_s,s_w,s_s,s_x,s_y,x_d,y_d,f_o;
  
  
  // fill color
  int f_c =color(255);
  // stroke color
  
  PImage img;
  int s_c =color(0);
  // text color
  int t_c =color(0);
  // text font
  PFont t_f = createFont("Georgia",30);
  
  //button radius
  float[] radius = new float[4];
  
  //if clicked , if activate , click_effect active/not active , shadows (broken) , eneable : button can ba activate or not
  boolean click = false;
  boolean activate = false;
  boolean click_effect = false;
  boolean shadows = false;
  boolean eneable = true;
  boolean images = false;
 
  
  Button(String n, float pos_x, float pos_y, float wi, float he){
    name = n;
    x = pos_x;
    y = pos_y;
    w = wi;
    h = he;
    t_s = 10;
    f_o = 255;
    
  }
  
  Button(String n, float pos_x, float pos_y, float wi, float he, int fill_c, int stroke_c, int text_c, float text_s , PFont text_f,float stroke_w, float r){
    
    name = n;
    x = pos_x;
    y = pos_y;
    w = wi;
    h = he;
    f_c = fill_c;
    s_c = stroke_c;
    t_c = text_c;
    t_s = text_s;
    t_f = text_f;
    s_w = stroke_w;
    radius[0] = r;
    radius[1] = r;
    radius[2] = r;
    radius[3] = r;
    f_o = 255;
    
  }
  
  public void set_image(PImage image){
    
    img = image;
    images = true;
    
  }
  
  public void remove_image(){
    
    images = false;
    
  }
  
  public void diseable(){
     eneable = false; 
  }
  
  public void eneable(){
     eneable = true; 
  }
  
  public void set_effect(boolean effect, boolean shadows, float shadows_s, float shadows_x, float shadows_y){
    
    
    click_effect = effect;
    //s = shadow;
    s_s = shadows_s;
    s_x = shadows_x;
    s_y = shadows_y;
    
    
  }
  
  public void set_fill(int c_){
    
    f_c = c_;
    
  }
  
  public void set_stroke(int c_, float stroke_w, float[] r){
    
    s_c = c_;
    s_w = stroke_w;
    radius = r;
    
  }
  
  public void set_pos( float pos_x, float pos_y){
    
    x = pos_x;
    y = pos_y;
    
  }
  
  public void set_size(  float wi, float he){
    
    w = wi;
    h = he;
    
  }
  
  public void set_text(  int text_c, float text_s , PFont text_f , float x_decal, float y_decal){
    
    t_c = text_c;
    t_s = text_s;
    t_f = text_f;
    x_d = x_decal;
    y_d = y_decal;
    
  }
  
  public void update(){
    
     if(activate){
        activate = false; 
     }
     if(eneable){
       maths_update();
     }
     graphics_update();
     
  }
  
  public boolean hover(){
    boolean reponse = false;
    
    if(mouseX < x+w && mouseX > x && mouseY < y+h && mouseY > y){
      
      reponse = true;
      
    }
    
    return(reponse);
  }
  
  public void maths_update(){
   if(activate){
      activate = false; 
   }
    
   if(mousePressed && !click && mouseButton == LEFT){
     if(hover()){
       click = true;
     }
   }
   if(!mousePressed && click || !hover()){
     if(hover()){
       activate = true;
     }
     click = false;
   }
   
   
    
  }
  
  public void graphics_update(){
    noTint();
    rectMode(CORNER);
    float decal = 0;
    if(click_effect && click){
       decal = 2; 
    }
    if(!eneable){
         
       tint(250,250,250,150);
       }
       if(hover() && eneable){
         
       tint(255,255,255,200);
       }
       
     if(click && eneable){
       
        
       tint(255,255,255,180);
       
     }
  
    if(images){
      image(img,x-decal,y+decal,w,h);
    }else{
        
      strokeWeight(s_w);
      noStroke();
     // rect(x+s_x,y+s_y,w*s_s,h*s_s,radius[0],radius[1],radius[2],radius[3]);
      fill(red(f_c),green(f_c),blue(f_c),f_o);
      stroke(s_c);
      rect(x-decal,y+decal,w,h,radius[0],radius[1],radius[2],radius[3]);
      if(click && eneable){
        
        fill(255,50);
        stroke(180);
          
  
        rect(x-decal,y+decal,w,h,radius[0],radius[1],radius[2],radius[3]);
        
      }
      
    }
    fill(t_c);
    noStroke();
    textAlign(CENTER, CENTER);
    textFont(t_f);
    strokeWeight(1);
    textSize(t_s);
    text(name,x+w/2-decal+x_d,y+h/2+decal+y_d);
    stroke(0);
    if(!images){
        if(!eneable){
           fill(255,120);
           strokeWeight(s_w);
           stroke(180);
           rect(x-decal,y+decal,w,h,radius[0],radius[1],radius[2],radius[3]);
          
        }
          if(hover() && eneable){
          
          noStroke();
          fill(230,100);
          rect(x-decal-s_w/2,y+decal-s_w/2,w+s_w,h+s_w,radius[0]+s_w,radius[1]+s_w,radius[2]+s_w,radius[3]+s_w);
          
        }
    }
  }
}



class Graphic{
  
  float x,y,w,h ;
  int fill_c = color(240);
  int stroke_c = color(70);
  int t_c = color(70);
  int f_t_c = color(150);
  float stroke_w = 1;
  int ratio = 1;
  Vector<Float> ordonee = new Vector<Float>();
  Vector<Float> abscice = new Vector<Float>();
  
  PFont t_f = createFont("Georgia",30);
  
  float lenght = 0;
  float start  = 0;
  
  String name,abs_unit,ord_unit;
  
  boolean absice_ponderee = false;
  
  boolean show_name = true;
  String name_pos = "CENTER";
  
  boolean Lsubdivide_1 = true;
  boolean Csubdivide_1 = true;
  
  float sub_Lsubdivide_ratio = 0.2f;
  float sub_Csubdivide_ratio = 0.33f;
  float pow_Lsubdivide_ratio = 1/sub_Lsubdivide_ratio;
  float pow_Csubdivide_ratio = 1/sub_Csubdivide_ratio;
  
  float unit_refC = 1;
  float unit_refL = 1;
  
  float subdivide_stroke = 3;
  
  int subdivision_color = color(20);
  int line_color = color(240,0,0);
  float line_weight = 1.5f;
  
  Graphic(String Name, float x_, float y_ , float w_, float h_ ,int background){
   
     name = Name;
     x = x_;
     y = y_;
     w = w_;
     h = h_;
     fill_c = background;
    
  }
  
    
  Graphic(String Name, float x_, float y_ , float w_, float h_ ,int background, int stroke_color , int stroke_weight){
   
     name = Name;
     x = x_;
     y = y_;
     w = w_;
     h = h_;
     fill_c = background;
     stroke_c = stroke_color;
     stroke_w = stroke_weight;

    
  }
  
  public void set_font( PFont font,int text_c , int fill_text_c){
    
    t_f = font;
    t_c = text_c;
    f_t_c = fill_text_c;
    
  }
  
  public void reset(){
   
    lenght = 0;
    ordonee = new Vector<Float>();
    abscice = new Vector<Float>();
    
  }
  
  public void set_lines(boolean O, boolean C , float ratio_subO , float ratio_subC , int div_c, float stroke_w, int line_c, float line_w,float refl,float refc,String unitl,String unitc){
    
      
    Lsubdivide_1 = O;
    Csubdivide_1 = C;
    
    sub_Lsubdivide_ratio = ratio_subO;
    sub_Csubdivide_ratio = ratio_subC;
    pow_Lsubdivide_ratio = 1/sub_Lsubdivide_ratio;
    pow_Csubdivide_ratio = 1/sub_Csubdivide_ratio;
    
    subdivide_stroke = stroke_w;
    
    subdivision_color = div_c;
    line_color = line_c;
    line_weight = line_w;
    
    
    unit_refC = refc;
    unit_refL = refl;
    
    
    abs_unit = unitl;
    ord_unit = unitc;
    
  }
  
  public void set_style(int background, int stroke_color , float stroke_weight ){
    
     fill_c = background;
     stroke_c = stroke_color;
     stroke_w = stroke_weight;
     
  }
  
  public void add(float value_1,float value_2){
    
    ordonee.add(value_1);
    abscice.add(value_2);
    lenght += 1;
    
  }
  
  public void add(float value){
    
    ordonee.add(value);
    if(absice_ponderee){
      if(lenght == 0){
        abscice.add((float)0);
        start = millis();
      }else{
        abscice.add((float)(millis()-start));
      }
    }else{
        abscice.add((float)(lenght));
    }
    lenght += 1;
    
  }
  
  public void simplify(int skipRate){
    int current_index = 0;
    while(abscice.size() > current_index){
      for(int i = 0; i < skipRate; i++){
          abscice.removeElementAt(i+current_index);
          ordonee.removeElementAt(i+current_index);
          lenght -= 1;
      }
      current_index ++;
    }
    
  }
  
  public void show(){
   
    rectMode(CENTER);
    textFont(t_f);
    
    fill(fill_c);
    stroke(stroke_c);
    strokeWeight(stroke_w);
    
    rect(x,y,w,h);
    textAlign(CENTER,CENTER);
    if(lenght != 0){
      float max_A = Collections.max(abscice);
      float max_O = Collections.max(ordonee);
      float min_A = Collections.min(abscice);
      if(min_A > 0){
         min_A = 0;
      }
      float min_O = Collections.min(ordonee);
      if(min_O > 0){
         min_O = 0;
      }
      
      float plage_A = max_A - min_A;
      float plage_O = max_O - min_O;
      
      float ratio_A = w/plage_A;
      float ratio_O = h/plage_O;
      
      float origine_A = Math.abs(min_A) * ratio_A;
      float origine_O = Math.abs(min_O) * ratio_O;
      
      textSize(11);
      
      if(plage_A != 0){
        float ratio = (w)/plage_A;
        float base = 1;
        while(ratio < w){
           ratio *= pow_Lsubdivide_ratio;
           base *= pow_Lsubdivide_ratio;
        }
        while(ratio > 3){
            stroke(red(subdivision_color),green(subdivision_color),blue(subdivision_color),(float)Math.pow(500*(ratio/w),1.5f));
            fill(red(subdivision_color),green(subdivision_color),blue(subdivision_color),(float)Math.pow(500*(ratio/w),1.5f));
            strokeWeight(15*(ratio/w));
            if(15*(ratio/w) > subdivide_stroke){
              strokeWeight(subdivide_stroke);
            }
            for(int i = 1; i*ratio < w-origine_A; i++){
              if(ratio > 20){
                 float value_f = (i)*base;
                 
                 String pow_10 = "";
                 if(value_f > 10000000000.0f){
                   value_f /= 10000000000.0f; 
                   pow_10 = " x10^(10)";
                 }
                 
                
                 
                 String value = value_f + "";
                 
                 text(value+pow_10,i*ratio+x-w/2-origine_A,y+h/2+15);
              }
              line(i*ratio+x-w/2-origine_A,y-h/2,i*ratio+x-w/2-origine_A,y+h/2);
              
            }
            
            //negative columns
            for(int i = -1; i*ratio+origine_A > 0; i--){
              if(ratio > 20){
                 float value_f = (i)*base;
                 String pow_10 = "";
                 if(value_f > 10000000000.0f){
                   value_f /= 10000000000.0f; 
                   pow_10 = " x10^(10)";
                 }
                 
                
                 
                 String value = value_f + "";
                 
                 text(value+pow_10,i*ratio+x-w/2-origine_A,y+h/2+15);
              }
              line(i*ratio+x-w/2-origine_A,y-h/2,i*ratio+x-w/2-origine_A,y+h/2);
              
            }
            ratio *= sub_Lsubdivide_ratio;
            base *= sub_Lsubdivide_ratio;
        }
        
        
      }
      
      
      
      if(plage_O != 0){
        float ratio = (h)/plage_O;
        float base = 1;
        while(ratio < h){
           ratio *= pow_Csubdivide_ratio;
           base *= pow_Csubdivide_ratio;
        }
        while(ratio > 3){
            stroke(red(subdivision_color),green(subdivision_color),blue(subdivision_color),(float)Math.pow(500*(ratio/h),1.5f));
            fill(red(subdivision_color),green(subdivision_color),blue(subdivision_color),(float)Math.pow(500*(ratio/h),1.5f));
            strokeWeight(15*(ratio/h));
            if(15*(ratio/h) > subdivide_stroke){
              strokeWeight(subdivide_stroke);
            }
            
            //positive lines
            for(int i = 1; i*ratio < h-origine_O; i++){
              if(ratio > 20){
                 float value_f = (i)*base;
                 String value = value_f + "";
                 if(value.length() > 4){
                   // value = value.substring(0,4);
                 }
                 text(value,x-w/2-textWidth(value)-10,y+h/2-i*ratio-origine_O);
              }
              line(x-w/2,y+h/2-i*ratio-origine_O,x+w/2,y+h/2-i*ratio-origine_O);
              
            }
            
            // negative lines
            for(int i = -1; i*ratio+origine_O > 0; i--){
              if(ratio > 20){
                 float value_f = (i)*base;
                 String value = value_f + "";
                 if(value.length() > 4){
                   // value = value.substring(0,4);
                 }
                 text(value,x-w/2-textWidth(value)-10,y+h/2-i*ratio-origine_O);
              }
              line(x-w/2,y+h/2-i*ratio-origine_O,x+w/2,y+h/2-i*ratio-origine_O);
              
            }
            ratio *= sub_Csubdivide_ratio;
            base *= sub_Csubdivide_ratio;
        }
        
      }
      
      strokeWeight(2);
      stroke(red(line_color)/4,green(line_color)/4,blue(line_color)/4);
      line(x-w/2,y+h/2-origine_O,x+w/2,y+h/2-origine_O);
      line(x-w/2+origine_A,y+h/2,x-w/2+origine_A,y-h/2);
      
      
      
      strokeWeight(2);
      stroke(line_color);
      for(int i = 0; i + ratio < lenght; i+=ratio){
       
        
        line(abscice.get(i)*ratio_A+x-w/2-origine_A,y+h/2-ordonee.get(i)*ratio_O-origine_O,abscice.get(i+ratio)*ratio_A+x-w/2-origine_A,y+h/2-ordonee.get(i+ratio)*ratio_O-origine_O);
        
        
      }
    }
    if(show_name){
      if(name_pos == "CENTER"){
       
          fill(f_t_c);
          textSize(20);
          strokeWeight(0);
          rect(x,y-h/2+10,textWidth(name),20);
          stroke(t_c);
          fill(t_c);
          strokeWeight(1);
          text(name,x,y-h/2+10);
        
      }
    }
    rectMode(CORNER);
  }
  
  
}  
public class Radio{
  
  String name;
  
  float size;
  float x,y,s_w,c_s = 10;
  
  boolean click = false;
  boolean activate = false;
  
  int c_c = color(255,0,0);
  int background = color(255);
  int stroke = color(255);
  String type = "POINT";
  String shape = "RECT";
  
  Radio(String Name , float x_ , float y_, float Size , int fill_c , int stroke_c , float stroke_w , String TYPE){
   
      name = Name;
      x = x_;
      y = y_;
      size = Size;
      c_s = c_s * 0.8f;
      background = fill_c;
      stroke = stroke_c;
      s_w = stroke_w;
      shape = TYPE;
    
  }
  
  public void set_cursor(String TYPE, float Size, int color_c){
    
    type = TYPE;
    c_s = Size;
    c_c = color_c;
    
  }
  
  public void update(){
    
     maths_update();
     graphics_update();
     
  }
  
    public boolean hover(){
        boolean reponse = false;
        
        if(mouseX < x+size/2 && mouseX > x-size/2 && mouseY < y+size/2 && mouseY > y-size/2){
          
          reponse = true;
          
        }
          
          return(reponse);
    }
      
  
  
  public void maths_update(){
     if(mousePressed && !click && mouseButton == LEFT){
         if(hover()){
           click = true;
         }
       }
       if(!mousePressed && click){
         if(hover()){
           if(activate){
             activate = false;
           }else{
             activate = true;
           }
         }
         click = false;
       }
    
    
    
  }
  
  public void graphics_update(){
    
    fill(background);
    stroke(0);
    strokeWeight(s_w);
    rectMode(CENTER);
    if(shape == "RECT"){
      rect(x,y,size,size);
    }else{
      ellipse(x,y,size,size);
    }
    
    noStroke();
    if(hover()){
      
      fill(240,100);
       if(shape == "RECT"){
         rect(x,y,size+s_w,size+s_w);
       }else{
         ellipse(x,y,size+s_w,size+s_w);
       }
      
    }
    
    if(click){
      
      fill(80,100);
       if(shape == "RECT"){
         rect(x,y,size+s_w,size+s_w);
       }else{
         ellipse(x,y,size+s_w,size+s_w);
       }
      
    }
    
    if(activate){
      
      fill(c_c);
      if(type  == "POINT"){
         ellipse(x+1,y+1,c_s,c_s);
      }else if(type == "RECT"){
         rect(x+1,y+1,c_s,c_s);
      }else if(type == "CROIX"){
         quad(x-c_s/2+1,y+1-(c_s/4),x+1-c_s/4,y+1-(c_s/2),x+1+c_s/2,y+1+(c_s/4),x+1+c_s/4,y+1+(c_s/2));
         quad(x-c_s/2+1,y+1+(c_s/4),x+1-c_s/4,y+1+(c_s/2),x+1+c_s/2,y+1-(c_s/4),x+1+c_s/4,y+1-(c_s/2));
      }else{
         ellipse(x,y,c_s,c_s);
      }
      
    }
    
    rectMode(CORNER);
  }

}
public class Slider{
  
  float x,y,l,min,max,s_w,h_g,b_g;
  float t_s = 15;
  float value = 0;
  float c_s_w =1;
  float c_x = 15,c_y = 15;
  int c_c,c_s_c = color(0);
  int s_c;
  int type = 0;
  String name;
  int t_c =color(0);
  PFont t_f = createFont("Georgia",30);
  float ghost_value = 0;
  
  float drag = x;  
  boolean click = false;
  
  boolean round_value = false;
 
  
  
  
  Slider(String n,float x_ ,float y_ , float l_ , float mi , float ma){
     
     x = x_; 
     y = y_;
     l = l_;
     min = mi;
     max = ma;
     name = n;
      
  }
  
  Slider(String n,float x_ ,float y_ , float l_ , float mi , float ma ,int stroke_c, float stroke_w){
     
     x = x_; 
     y = y_;
     l = l_;
     min = mi;
     value= min;
     max = ma;
     s_c = stroke_c;
     s_w = stroke_w;
     name = n;
     value = min;
      
      
  }
  
  public void set_text(String n,  int text_c, float text_s , PFont text_f){
    
    name = n;
    t_c = text_c;
    t_s = text_s;
    t_f = text_f;
    
  }
  
  public void set_cursor(int t,float  cursor_x , float cursor_y, int cursor_c,int cursor_stroke_c,float cursor_stroke_w){
    
    type = t;
    c_x = cursor_x;
    c_y = cursor_y;
    c_c = cursor_c;
    c_s_c = cursor_stroke_c;
    c_s_w = cursor_stroke_w;
    
  }
  
  public void set_grad(float mi, float ma, float haut_g, float bas_g, float pos){
    
     min = mi;
     max = ma;
     h_g = haut_g;
     b_g = bas_g;
     value = pos;
     ghost_value = value;
    
  }
  
  public void graphics_update(){
    
    rectMode(CORNER);
    stroke(s_c);
    strokeWeight(s_w);
    line(x,y,x+l,y);
    line(x,y-7,x,y+7);
    line(x+l,y-7,x+l,y+7);
    
    float ratio = l/(max-min);
    if( h_g !=0){
      strokeWeight(s_w*0.7f);
      for(float i = min; i < max ; i += h_g){
       
        line((i-min)*ratio+x,y-5,(i-min)*ratio+x,y+5);
       
      } 
    }
    if(b_g != 0){
      strokeWeight(s_w*0.4f);
      for(float i = min; i < max ; i += b_g){
       
        line((i-min)*ratio+x,y-4,(i-min)*ratio+x,y+4);
       
      } 
    }
    
    fill(c_c);
    stroke(c_s_c);
    strokeWeight(c_s_w);
    if(type == 0){
      ellipse((value-min)*ratio+x,y,c_x,c_y);
    }else{
      rect((value-min)*ratio+x-c_x/2,y-c_y/2,c_x,c_y);
    }
    noStroke();
    textFont(t_f);
    textSize(t_s);
    fill(t_c);
    textAlign(LEFT, BOTTOM);
    text(name+" :",x,y-10);
   // textAlign(LEFT, CENTER);
    text(name+" :",x,y-10);
   // textAlign(LEFT, TOP);
    text(name+" :",x,y-10);
    
    
  }
  
  public void update(){
   
   physics_update();
   graphics_update(); 
    
  }
  
  public void physics_update(){
    
    if(value > max){
       value = max; 
    }
    if(value < min){
       value = min;
    }
    if(mousePressed && !click && mouseButton == LEFT){
     if(hover()){
       click = true;
       drag = mouseX;
       ghost_value = value;
     }
   }
   if(!mousePressed && click){
     
       
       click = false;
       drag = x;
     
   }
   if(click){
     
     
     float ratio = (max-min)/l;
     
     float movement = mouseX-drag;
     
     ghost_value += movement*ratio;
     if(round_value){
       value = Math.round(clamp(ghost_value,min,max));
     }else{
       value = clamp(ghost_value,min,max);
     }
     System.out.println(value);
    
     drag = mouseX;
       
     
   }
    
  }
  
  
  
  public float clamp(float v, float mi,float ma){
     float result = v;
     if(v > ma){
          result = ma; 
           System.out.println("too big");
     }
     if(v < mi){
          result = mi; 
     }
     return(result);
  }
  
  public boolean hover(){
    
    float ratio = l/(max-min);
    boolean reponse = false;
    
    if(mouseX < (value-min)*ratio+x+c_x/2 && mouseX > (value-min)*ratio+x-c_x/2 && mouseY < y+c_y/2 && mouseY > y-c_y/2){
      
      reponse = true;
      
    }
    
    return(reponse);
  }

  
  
}
  public void settings() {  size(1500,800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "CELLSIM" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
